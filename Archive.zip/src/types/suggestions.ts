export interface Suggestions {
  [key: string]: string[];
}